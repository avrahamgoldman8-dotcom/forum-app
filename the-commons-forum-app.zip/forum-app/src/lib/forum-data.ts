import { prisma } from "@/lib/prisma";

export type LatestPost = {
  createdAt: Date;
  authorName: string;
  threadTitle: string;
  threadId: string;
} | null;

async function latestPostForForumIds(forumIds: string[]): Promise<LatestPost> {
  if (forumIds.length === 0) return null;
  const post = await prisma.post.findFirst({
    where: { thread: { forumId: { in: forumIds } } },
    orderBy: { createdAt: "desc" },
    include: { author: true, thread: true },
  });
  if (!post) return null;
  return {
    createdAt: post.createdAt,
    authorName: post.author.name,
    threadTitle: post.thread.title,
    threadId: post.thread.id,
  };
}

export async function getForumTree() {
  const mains = await prisma.forum.findMany({
    where: { parentId: null },
    orderBy: { order: "asc" },
    include: {
      children: { orderBy: { order: "asc" } },
    },
  });

  const tree = await Promise.all(
    mains.map(async (main) => {
      const childCounts = await Promise.all(
        main.children.map(async (child) => {
          const [threadCount, latest] = await Promise.all([
            prisma.thread.count({ where: { forumId: child.id } }),
            latestPostForForumIds([child.id]),
          ]);
          return { ...child, threadCount, latest };
        })
      );

      const ownThreadCount = await prisma.thread.count({
        where: { forumId: main.id },
      });
      const allDescendantIds = [main.id, ...main.children.map((c) => c.id)];
      const latest = await latestPostForForumIds(allDescendantIds);
      const totalThreadCount =
        ownThreadCount + childCounts.reduce((s, c) => s + c.threadCount, 0);

      return {
        ...main,
        ownThreadCount,
        totalThreadCount,
        latest,
        children: childCounts,
      };
    })
  );

  return tree;
}

export async function getForumBySlug(slug: string) {
  const forum = await prisma.forum.findUnique({
    where: { slug },
    include: {
      parent: true,
      children: { orderBy: { order: "asc" } },
    },
  });
  if (!forum) return null;

  const threads = await prisma.thread.findMany({
    where: { forumId: forum.id },
    orderBy: [{ pinned: "desc" }, { createdAt: "desc" }],
    include: {
      author: true,
      _count: { select: { posts: true } },
      posts: { orderBy: { createdAt: "desc" }, take: 1, include: { author: true } },
    },
  });

  return { forum, threads };
}

export async function getAllForumsFlat() {
  return prisma.forum.findMany({ orderBy: [{ parentId: "asc" }, { order: "asc" }] });
}

export async function getCombinedFeed(limit = 50) {
  const threads = await prisma.thread.findMany({
    orderBy: { createdAt: "desc" },
    take: limit,
    include: {
      author: true,
      forum: { include: { parent: true } },
      _count: { select: { posts: true } },
      posts: { orderBy: { createdAt: "desc" }, take: 1, include: { author: true } },
    },
  });
  return threads;
}
