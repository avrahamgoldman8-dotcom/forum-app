"use server";

import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { auth, signIn } from "@/lib/auth";
import { slugify } from "@/lib/slugify";

export async function registerUser(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "")
    .trim()
    .toLowerCase();
  const password = String(formData.get("password") ?? "");

  if (!name || !email || !password || password.length < 8) {
    throw new Error(
      "Please fill in a name, a valid email, and a password of at least 8 characters."
    );
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    throw new Error("An account with that email already exists.");
  }

  const passwordHash = await bcrypt.hash(password, 10);

  // First user ever created becomes ADMIN so the site has an owner.
  const userCount = await prisma.user.count();

  await prisma.user.create({
    data: {
      name,
      email,
      passwordHash,
      role: userCount === 0 ? "ADMIN" : "MEMBER",
    },
  });

  await signIn("credentials", { email, password, redirectTo: "/" });
}

export async function createForum(formData: FormData) {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    throw new Error("Only admins can create forums.");
  }

  const name = String(formData.get("name") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const parentId = String(formData.get("parentId") ?? "") || null;

  if (!name) throw new Error("A forum name is required.");

  let slug = slugify(name);
  const clash = await prisma.forum.findUnique({ where: { slug } });
  if (clash) slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;

  await prisma.forum.create({
    data: { name, description, slug, parentId },
  });

  revalidatePath("/");
  revalidatePath("/admin/forums");
}

export async function deleteForum(formData: FormData) {
  const session = await auth();
  if (!session?.user || session.user.role !== "ADMIN") {
    throw new Error("Only admins can delete forums.");
  }
  const id = String(formData.get("id") ?? "");
  if (!id) return;
  await prisma.forum.delete({ where: { id } });
  revalidatePath("/");
  revalidatePath("/admin/forums");
}

export async function createThread(formData: FormData) {
  const session = await auth();
  if (!session?.user) throw new Error("You must be signed in to post.");

  const forumId = String(formData.get("forumId") ?? "");
  const title = String(formData.get("title") ?? "").trim();
  const content = String(formData.get("content") ?? "").trim();

  if (!forumId || !title || !content) {
    throw new Error("A title and message are required.");
  }

  const forum = await prisma.forum.findUnique({ where: { id: forumId } });
  if (!forum) throw new Error("That forum does not exist.");

  let slug = slugify(title) || "thread";
  const clash = await prisma.thread.findUnique({
    where: { forumId_slug: { forumId, slug } },
  });
  if (clash) slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;

  const thread = await prisma.thread.create({
    data: {
      title,
      slug,
      forumId,
      authorId: session.user.id,
      posts: { create: { content, authorId: session.user.id } },
    },
  });

  revalidatePath(`/forum/${forum.slug}`);
  revalidatePath("/all");
  redirect(`/thread/${thread.id}`);
}

export async function createPost(formData: FormData) {
  const session = await auth();
  if (!session?.user) throw new Error("You must be signed in to reply.");

  const threadId = String(formData.get("threadId") ?? "");
  const content = String(formData.get("content") ?? "").trim();
  if (!threadId || !content) throw new Error("A message is required.");

  const thread = await prisma.thread.findUnique({ where: { id: threadId } });
  if (!thread) throw new Error("That thread does not exist.");
  if (thread.locked) throw new Error("This thread is locked.");

  await prisma.post.create({
    data: { content, threadId, authorId: session.user.id },
  });

  revalidatePath(`/thread/${threadId}`);
  revalidatePath("/all");
}
