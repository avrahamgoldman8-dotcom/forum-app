export function ShelfTab({
  label,
  kind,
  size = "md",
}: {
  label: string;
  kind: "main" | "sub";
  size?: "sm" | "md";
}) {
  const initial = label.trim().charAt(0).toUpperCase() || "?";
  const dims = size === "sm" ? "h-6 w-6 text-[11px]" : "h-8 w-8 text-sm";

  return (
    <span
      title={label}
      className={`shelf-tab inline-flex ${dims} shrink-0 items-center justify-center rounded-sm ${
        kind === "main"
          ? "bg-brass-soft text-brass"
          : "bg-teal-soft text-teal"
      }`}
      aria-hidden="true"
    >
      {initial}
    </span>
  );
}
