import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { getAllForumsFlat } from "@/lib/forum-data";
import { createForum, deleteForum } from "@/lib/actions";
import { ShelfTab } from "@/components/ShelfTab";

export default async function AdminForumsPage() {
  const session = await auth();
  if (!session?.user) redirect("/login?next=/admin/forums");
  if (session.user.role !== "ADMIN") redirect("/");

  const forums = await getAllForumsFlat();
  const mains = forums.filter((f) => !f.parentId);

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-ink">
        Manage forums
      </h1>
      <p className="mt-1 text-sm text-ink-soft">
        Leave &quot;parent forum&quot; unset to create a main forum, or choose
        one to create a subforum beneath it.
      </p>

      <form
        action={createForum}
        className="mt-6 space-y-4 rounded-sm border border-line bg-paper-raised p-4"
      >
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Name
          </label>
          <input
            name="name"
            required
            className="mt-1 w-full rounded-sm border border-line px-3 py-2 text-ink"
          />
        </div>
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Description (optional)
          </label>
          <input
            name="description"
            className="mt-1 w-full rounded-sm border border-line px-3 py-2 text-ink"
          />
        </div>
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Parent forum
          </label>
          <select
            name="parentId"
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
          >
            <option value="">— none (main forum) —</option>
            {mains.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        </div>
        <button
          type="submit"
          className="rounded-sm bg-teal px-4 py-2 font-mono text-xs uppercase tracking-wider text-paper-raised hover:bg-ink"
        >
          Create forum
        </button>
      </form>

      <div className="mt-8 divide-y divide-line rounded-sm border border-line bg-paper-raised">
        {forums.map((f) => (
          <div key={f.id} className="flex items-center gap-3 p-3">
            <ShelfTab
              label={f.name}
              kind={f.parentId ? "sub" : "main"}
              size="sm"
            />
            <span className="flex-1 text-sm text-ink">
              {f.parentId ? "— " : ""}
              {f.name}
            </span>
            <form action={deleteForum}>
              <input type="hidden" name="id" value={f.id} />
              <button
                type="submit"
                className="font-mono text-[11px] uppercase tracking-wider text-coral hover:underline"
              >
                Delete
              </button>
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}
