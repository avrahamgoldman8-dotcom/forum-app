import Link from "next/link";
import { getForumTree } from "@/lib/forum-data";
import { ShelfTab } from "@/components/ShelfTab";
import { timeAgo } from "@/lib/time";

export default async function HomePage() {
  const forums = await getForumTree();

  return (
    <div>
      <div className="mb-8 flex items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-semibold text-ink">
            Forums
          </h1>
          <p className="mt-1 text-sm text-ink-soft">
            Brass tabs mark main forums, teal tabs mark the subforums beneath
            them — every thread stays filed under one, wherever you read it.
          </p>
        </div>
        <Link
          href="/all"
          className="hidden sm:inline-block whitespace-nowrap rounded-sm border border-line px-3 py-2 font-mono text-xs uppercase tracking-wider text-ink-soft hover:border-teal hover:text-teal"
        >
          View all activity →
        </Link>
      </div>

      {forums.length === 0 && (
        <div className="rounded-sm border border-dashed border-line bg-paper-raised p-10 text-center">
          <p className="text-ink-soft">
            No forums yet. An admin can add the first main forum from{" "}
            <Link href="/admin/forums" className="text-teal underline">
              Manage
            </Link>
            .
          </p>
        </div>
      )}

      <div className="space-y-6">
        {forums.map((forum) => (
          <section
            key={forum.id}
            className="rounded-sm border border-line bg-paper-raised"
          >
            <div className="flex items-start gap-3 border-b border-line p-4">
              <ShelfTab label={forum.name} kind="main" />
              <div className="min-w-0 flex-1">
                <Link
                  href={`/forum/${forum.slug}`}
                  className="font-display text-lg font-semibold text-ink hover:text-teal"
                >
                  {forum.name}
                </Link>
                {forum.description && (
                  <p className="mt-0.5 text-sm text-ink-soft">
                    {forum.description}
                  </p>
                )}
              </div>
              <div className="hidden shrink-0 text-right font-mono text-xs text-ink-soft sm:block">
                <div>{forum.totalThreadCount} threads</div>
                {forum.latest && (
                  <div className="mt-0.5">
                    last: {timeAgo(new Date(forum.latest.createdAt))}
                  </div>
                )}
              </div>
            </div>

            {forum.children.length > 0 && (
              <div className="divide-y divide-line">
                {forum.children.map((child) => (
                  <Link
                    key={child.id}
                    href={`/forum/${child.slug}`}
                    className="flex items-center gap-3 p-3 pl-8 hover:bg-teal-soft/40"
                  >
                    <ShelfTab label={child.name} kind="sub" size="sm" />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium text-ink">
                        {child.name}
                      </div>
                      {child.description && (
                        <div className="truncate text-xs text-ink-soft">
                          {child.description}
                        </div>
                      )}
                    </div>
                    <div className="hidden shrink-0 text-right font-mono text-[11px] text-ink-soft sm:block">
                      <div>{child.threadCount} threads</div>
                      {child.latest && (
                        <div>{timeAgo(new Date(child.latest.createdAt))}</div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </section>
        ))}
      </div>
    </div>
  );
}
