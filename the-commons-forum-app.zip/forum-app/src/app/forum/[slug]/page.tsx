import Link from "next/link";
import { notFound } from "next/navigation";
import { getForumBySlug } from "@/lib/forum-data";
import { ShelfTab } from "@/components/ShelfTab";
import { timeAgo } from "@/lib/time";
import { auth } from "@/lib/auth";

export default async function ForumPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const data = await getForumBySlug(slug);
  if (!data) notFound();
  const { forum, threads } = data;
  const session = await auth();
  const isSub = !!forum.parentId;

  return (
    <div>
      <div className="mb-4 font-mono text-xs uppercase tracking-wider text-ink-soft">
        <Link href="/" className="hover:text-teal">
          Forums
        </Link>
        {isSub && forum.parent && (
          <>
            <span className="mx-1.5">/</span>
            <Link href={`/forum/${forum.parent.slug}`} className="hover:text-teal">
              {forum.parent.name}
            </Link>
          </>
        )}
        <span className="mx-1.5">/</span>
        <span className="text-ink">{forum.name}</span>
      </div>

      <div className="mb-6 flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <ShelfTab label={forum.name} kind={isSub ? "sub" : "main"} />
          <div>
            <h1 className="font-display text-2xl font-semibold text-ink">
              {forum.name}
            </h1>
            {forum.description && (
              <p className="mt-1 text-sm text-ink-soft">{forum.description}</p>
            )}
          </div>
        </div>
        {session?.user ? (
          <Link
            href={`/forum/${forum.slug}/new`}
            className="whitespace-nowrap rounded-sm bg-teal px-3 py-2 font-mono text-xs uppercase tracking-wider text-paper-raised hover:bg-ink"
          >
            New thread
          </Link>
        ) : (
          <Link
            href="/login"
            className="whitespace-nowrap rounded-sm border border-line px-3 py-2 font-mono text-xs uppercase tracking-wider text-ink-soft hover:border-teal hover:text-teal"
          >
            Sign in to post
          </Link>
        )}
      </div>

      {!isSub && forum.children.length > 0 && (
        <div className="mb-6 grid gap-2 sm:grid-cols-2">
          {forum.children.map((child) => (
            <Link
              key={child.id}
              href={`/forum/${child.slug}`}
              className="flex items-center gap-2 rounded-sm border border-line bg-paper-raised p-3 hover:border-teal"
            >
              <ShelfTab label={child.name} kind="sub" size="sm" />
              <span className="text-sm font-medium text-ink">{child.name}</span>
            </Link>
          ))}
        </div>
      )}

      <div className="divide-y divide-line rounded-sm border border-line bg-paper-raised">
        {threads.length === 0 && (
          <p className="p-8 text-center text-ink-soft">
            No threads here yet.{" "}
            {session?.user ? (
              <Link href={`/forum/${forum.slug}/new`} className="text-teal underline">
                Start the first one.
              </Link>
            ) : (
              "Sign in to start one."
            )}
          </p>
        )}
        {threads.map((thread) => (
          <Link
            key={thread.id}
            href={`/thread/${thread.id}`}
            className="flex items-center gap-3 p-3 hover:bg-teal-soft/30"
          >
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-medium text-ink">
                {thread.pinned && (
                  <span className="mr-1.5 text-brass">Pinned ·</span>
                )}
                {thread.title}
                {thread.locked && (
                  <span className="ml-1.5 text-ink-soft">(locked)</span>
                )}
              </div>
              <div className="mt-0.5 font-mono text-[11px] text-ink-soft">
                by {thread.author.name} · {thread._count.posts} posts
              </div>
            </div>
            <div className="hidden shrink-0 text-right font-mono text-[11px] text-ink-soft sm:block">
              {thread.posts[0] && <div>{thread.posts[0].author.name}</div>}
              <div>{timeAgo(new Date(thread.createdAt))}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
