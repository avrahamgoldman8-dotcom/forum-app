import { notFound, redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { createThread } from "@/lib/actions";

export default async function NewThreadPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect(`/login?next=/forum/${slug}/new`);

  const forum = await prisma.forum.findUnique({ where: { slug } });
  if (!forum) notFound();

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-display text-2xl font-semibold text-ink">
        New thread in {forum.name}
      </h1>
      <form action={createThread} className="mt-6 space-y-4">
        <input type="hidden" name="forumId" value={forum.id} />
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Title
          </label>
          <input
            name="title"
            required
            maxLength={140}
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
            placeholder="What's this thread about?"
          />
        </div>
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Message
          </label>
          <textarea
            name="content"
            required
            rows={8}
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
            placeholder="Write the opening post…"
          />
        </div>
        <button
          type="submit"
          className="rounded-sm bg-teal px-4 py-2 font-mono text-xs uppercase tracking-wider text-paper-raised hover:bg-ink"
        >
          Post thread
        </button>
      </form>
    </div>
  );
}
