import Link from "next/link";
import { redirect } from "next/navigation";
import { signIn } from "@/lib/auth";
import { AuthError } from "next-auth";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; error?: string }>;
}) {
  const { next, error } = await searchParams;

  async function login(formData: FormData) {
    "use server";
    const email = String(formData.get("email") ?? "");
    const password = String(formData.get("password") ?? "");
    const dest = String(formData.get("next") ?? "/");
    try {
      await signIn("credentials", { email, password, redirectTo: dest });
    } catch (err) {
      if (err instanceof AuthError) {
        redirect(`/login?error=1${dest ? `&next=${encodeURIComponent(dest)}` : ""}`);
      }
      throw err;
    }
  }

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="font-display text-2xl font-semibold text-ink">Sign in</h1>
      {error && (
        <p className="mt-3 rounded-sm border border-coral/40 bg-coral/10 p-2 text-sm text-coral">
          That email and password don&apos;t match. Try again.
        </p>
      )}
      <form action={login} className="mt-6 space-y-4">
        <input type="hidden" name="next" value={next ?? "/"} />
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Email
          </label>
          <input
            type="email"
            name="email"
            required
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
          />
        </div>
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Password
          </label>
          <input
            type="password"
            name="password"
            required
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
          />
        </div>
        <button
          type="submit"
          className="w-full rounded-sm bg-teal px-4 py-2 font-mono text-xs uppercase tracking-wider text-paper-raised hover:bg-ink"
        >
          Sign in
        </button>
      </form>
      <p className="mt-4 text-sm text-ink-soft">
        No account?{" "}
        <Link href="/register" className="text-teal underline">
          Join the commons
        </Link>
      </p>
    </div>
  );
}
