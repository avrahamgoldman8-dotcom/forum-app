import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { createPost } from "@/lib/actions";
import { ShelfTab } from "@/components/ShelfTab";
import { timeAgo } from "@/lib/time";

export default async function ThreadPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const session = await auth();

  const thread = await prisma.thread.findUnique({
    where: { id },
    include: {
      forum: { include: { parent: true } },
      author: true,
      posts: { orderBy: { createdAt: "asc" }, include: { author: true } },
    },
  });
  if (!thread) notFound();
  const isSub = !!thread.forum.parentId;

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-4 font-mono text-xs uppercase tracking-wider text-ink-soft">
        <Link href="/" className="hover:text-teal">
          Forums
        </Link>
        <span className="mx-1.5">/</span>
        {isSub && thread.forum.parent && (
          <>
            <Link href={`/forum/${thread.forum.parent.slug}`} className="hover:text-teal">
              {thread.forum.parent.name}
            </Link>
            <span className="mx-1.5">/</span>
          </>
        )}
        <Link href={`/forum/${thread.forum.slug}`} className="hover:text-teal">
          {thread.forum.name}
        </Link>
      </div>

      <div className="mb-6 flex items-start gap-3">
        <ShelfTab label={thread.forum.name} kind={isSub ? "sub" : "main"} />
        <h1 className="font-display text-2xl font-semibold text-ink">
          {thread.title}
        </h1>
      </div>

      <div className="space-y-4">
        {thread.posts.map((post, i) => (
          <article
            key={post.id}
            className="rounded-sm border border-line bg-paper-raised p-4"
          >
            <div className="mb-2 flex items-center justify-between font-mono text-[11px] text-ink-soft">
              <span className="font-medium text-ink">
                {post.author.name}
                {i === 0 && (
                  <span className="ml-2 rounded-sm bg-brass-soft px-1.5 py-0.5 text-brass">
                    original post
                  </span>
                )}
              </span>
              <span>{timeAgo(new Date(post.createdAt))}</span>
            </div>
            <p className="whitespace-pre-wrap text-sm leading-relaxed text-ink">
              {post.content}
            </p>
          </article>
        ))}
      </div>

      <div className="mt-8">
        {thread.locked ? (
          <p className="rounded-sm border border-dashed border-line p-4 text-center text-ink-soft">
            This thread is locked. No new replies.
          </p>
        ) : session?.user ? (
          <form action={createPost} className="space-y-3">
            <input type="hidden" name="threadId" value={thread.id} />
            <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
              Reply
            </label>
            <textarea
              name="content"
              required
              rows={5}
              className="w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
              placeholder="Add to the thread…"
            />
            <button
              type="submit"
              className="rounded-sm bg-teal px-4 py-2 font-mono text-xs uppercase tracking-wider text-paper-raised hover:bg-ink"
            >
              Post reply
            </button>
          </form>
        ) : (
          <p className="rounded-sm border border-line bg-paper-raised p-4 text-center text-ink-soft">
            <Link href="/login" className="text-teal underline">
              Sign in
            </Link>{" "}
            to reply.
          </p>
        )}
      </div>
    </div>
  );
}
