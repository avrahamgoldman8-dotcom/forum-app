import Link from "next/link";
import { getCombinedFeed } from "@/lib/forum-data";
import { ShelfTab } from "@/components/ShelfTab";
import { timeAgo } from "@/lib/time";

export default async function AllActivityPage() {
  const threads = await getCombinedFeed(75);

  return (
    <div>
      <div className="mb-6">
        <h1 className="font-display text-3xl font-semibold text-ink">
          All Activity
        </h1>
        <p className="mt-1 text-sm text-ink-soft">
          Every thread from every forum, newest first. The tab on each row
          shows exactly where it lives — nothing here is merged, only
          gathered.
        </p>
      </div>

      <div className="divide-y divide-line rounded-sm border border-line bg-paper-raised">
        {threads.length === 0 && (
          <p className="p-8 text-center text-ink-soft">
            Nothing posted yet. Be the first to start a thread.
          </p>
        )}
        {threads.map((thread) => {
          const isSub = !!thread.forum.parentId;
          const lastPost = thread.posts[0];
          return (
            <Link
              key={thread.id}
              href={`/thread/${thread.id}`}
              className="flex items-center gap-3 p-3 hover:bg-teal-soft/30"
            >
              <ShelfTab
                label={thread.forum.name}
                kind={isSub ? "sub" : "main"}
              />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium text-ink">
                  {thread.title}
                </div>
                <div className="mt-0.5 flex flex-wrap items-center gap-x-2 font-mono text-[11px] text-ink-soft">
                  <span>
                    {isSub && thread.forum.parent
                      ? `${thread.forum.parent.name} / `
                      : ""}
                    {thread.forum.name}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>by {thread.author.name}</span>
                  <span aria-hidden="true">·</span>
                  <span>{thread._count.posts} posts</span>
                </div>
              </div>
              <div className="hidden shrink-0 text-right font-mono text-[11px] text-ink-soft sm:block">
                {lastPost && <div>{lastPost.author.name}</div>}
                <div>{timeAgo(new Date(thread.createdAt))}</div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
