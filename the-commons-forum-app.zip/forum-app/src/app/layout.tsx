import type { Metadata } from "next";
import { Lora, IBM_Plex_Sans, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { auth, signOut } from "@/lib/auth";
import Link from "next/link";

const lora = Lora({
  variable: "--font-lora",
  subsets: ["latin"],
  weight: ["500", "600", "700"],
});

const plexSans = IBM_Plex_Sans({
  variable: "--font-plex-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
});

const plexMono = IBM_Plex_Mono({
  variable: "--font-plex-mono",
  subsets: ["latin"],
  weight: ["400", "500"],
});

export const metadata: Metadata = {
  title: "The Commons — Community Forums",
  description: "Main forums and subforums, all in one reading room.",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const session = await auth();

  return (
    <html lang="en">
      <body
        className={`${lora.variable} ${plexSans.variable} ${plexMono.variable} antialiased`}
      >
        <header className="border-b border-line bg-paper-raised">
          <div className="mx-auto max-w-5xl px-5 py-4 flex items-center justify-between gap-4">
            <Link href="/" className="flex items-baseline gap-2">
              <span className="font-display text-xl font-semibold tracking-tight text-ink">
                The Commons
              </span>
              <span className="hidden sm:inline font-mono text-[11px] uppercase tracking-wider text-ink-soft">
                community reading room
              </span>
            </Link>
            <nav className="flex items-center gap-4 font-mono text-xs uppercase tracking-wider">
              <Link href="/" className="text-ink-soft hover:text-ink">
                Forums
              </Link>
              <Link href="/all" className="text-ink-soft hover:text-ink">
                All Activity
              </Link>
              {session?.user?.role === "ADMIN" && (
                <Link href="/admin/forums" className="text-ink-soft hover:text-ink">
                  Manage
                </Link>
              )}
              {session?.user ? (
                <form
                  action={async () => {
                    "use server";
                    await signOut({ redirectTo: "/" });
                  }}
                >
                  <button className="text-ink-soft hover:text-coral" type="submit">
                    Sign out ({session.user.name?.split(" ")[0]})
                  </button>
                </form>
              ) : (
                <>
                  <Link href="/login" className="text-ink-soft hover:text-ink">
                    Sign in
                  </Link>
                  <Link
                    href="/register"
                    className="rounded-sm bg-teal px-3 py-1.5 text-paper-raised normal-case tracking-normal hover:bg-ink"
                  >
                    Join
                  </Link>
                </>
              )}
            </nav>
          </div>
        </header>
        <main className="mx-auto max-w-5xl px-5 py-8">{children}</main>
        <footer className="mx-auto max-w-5xl px-5 py-10 font-mono text-[11px] text-ink-soft">
          The Commons — main forums &amp; subforums, kept separate, viewable as one.
        </footer>
      </body>
    </html>
  );
}
