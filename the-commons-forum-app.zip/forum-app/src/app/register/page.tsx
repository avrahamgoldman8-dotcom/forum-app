import Link from "next/link";
import { redirect } from "next/navigation";
import { registerUser } from "@/lib/actions";

export default async function RegisterPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;

  async function register(formData: FormData) {
    "use server";
    try {
      await registerUser(formData);
    } catch (err) {
      const digest = (err as { digest?: string })?.digest;
      if (digest?.startsWith("NEXT_REDIRECT")) throw err;
      const message = err instanceof Error ? err.message : "Something went wrong.";
      redirect(`/register?error=${encodeURIComponent(message)}`);
    }
  }

  return (
    <div className="mx-auto max-w-sm">
      <h1 className="font-display text-2xl font-semibold text-ink">
        Join the commons
      </h1>
      {error && (
        <p className="mt-3 rounded-sm border border-coral/40 bg-coral/10 p-2 text-sm text-coral">
          {error}
        </p>
      )}
      <form action={register} className="mt-6 space-y-4">
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Name
          </label>
          <input
            name="name"
            required
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
          />
        </div>
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Email
          </label>
          <input
            type="email"
            name="email"
            required
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
          />
        </div>
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-ink-soft">
            Password
          </label>
          <input
            type="password"
            name="password"
            required
            minLength={8}
            className="mt-1 w-full rounded-sm border border-line bg-paper-raised px-3 py-2 text-ink"
          />
          <p className="mt-1 font-mono text-[11px] text-ink-soft">
            At least 8 characters.
          </p>
        </div>
        <button
          type="submit"
          className="w-full rounded-sm bg-teal px-4 py-2 font-mono text-xs uppercase tracking-wider text-paper-raised hover:bg-ink"
        >
          Create account
        </button>
      </form>
      <p className="mt-4 text-sm text-ink-soft">
        Already have an account?{" "}
        <Link href="/login" className="text-teal underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
